Come si pu� chiaramente vedere, l'esercitazione � insufficiente.
Non ero assolutamente pronto per esercizio di questo genere.
Cercher� di prepararmi adeguatamente per la prossima volta.

MArco Antonino