package enumeration;
/*
 * Sono tipi discreti, sono limitati e una volta che 
 */
public enum Alimentazione {
	BENZINA,DIESEL,GPL,METANO,IBRIDA;
}
